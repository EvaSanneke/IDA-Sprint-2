// let n = 0; /*schlüsselwort let und variablenname. zuweisung des werts von rechts nach links */
// function buttonPressed() {
//   n++;
//   document.getElementById("element").style.left = n + "px";
// }

// function neuesElement() {
//   let div = document.createElement("div");
//   div.classList.add("random");
//   div.style.left = Math.random() * window.innerWidth + "px";
//   div.style.top = Math.random() * window.innerHeight + "px";
//   document.body.appendChild(div);
// }

let n = 0; /*schlüsselwort let und variablenname. zuweisung des werts von rechts nach links */

function move() {
  n = n + 10; //n++
  let button = document.getElementById("button");
  button.style.backgroundColor = "red";
  button.style.left = n + "px";
  button.style.top = "500px";
  button.style.borderRadius = "50%";
}

function moveBack() {
  // n = n + 10; //n++
  let button = document.getElementById("button");
  button.style.backgroundColor = "greenyellow";
  button.style.left = "100px";
  button.style.top = "200px";
  button.style.borderRadius = "0%";
}

function move2() {
  n = n + 18; //n++
  let button = document.getElementById("button2");
  button.style.backgroundColor = "yellow";
  button.style.left = "1080px";
  button.style.borderRadius = "80%";
}

function moveBack2() {
  // n = n + 10; //n++
  let button = document.getElementById("button2");
  button.style.backgroundColor = "red";
  button.style.left = "300px";
  button.style.borderRadius = "0%";
}
