var speedx = 2;
var speedy = 2;
var x = 30;
var y = 200;

var clr = {
  r: 0,
  g: 0,
  b: 0,
};
var boxY = 60;
var boxX = 60;
var boxd = 30;

function setup() {
  createCanvas(windowWidth, windowHeight).parent("p5-container");
  clr.r = random(0, 255);
  clr.g = random(0, 255);
  clr.b = random(0, 255);
  x = random(boxd, width - boxd);
  y = random(boxd, height - boxd);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function draw() {
  clear();
  x += speedx;
  y += speedy;
  move();

  // RECTANGLE
  //   rectMode(CENTER);
  //   noStroke();
  //   fill(clr.r, clr.g, clr.b);
  //   circle(x, y, boxX, boxY);

  noStroke();
  fill(clr.r, clr.g, clr.b);
  //   textAlign(CENTER, CENTER);

  textSize(22);
  text("take a break", x, y);
}

function randomClr() {
  clr.r = random(0, 255);
  clr.g = random(0, 255);
  clr.b = random(0, 255);
}

function move() {
  textSize(22);
  let tw = textWidth("take a break");
  let th = 22; // Approximate text height (can tweak as needed)

  // Bounce off right edge
  if (x > width - tw) {
    speedx = random(-4, -2);
    randomClr();
  }

  // Bounce off left edge
  if (x < 0) {
    speedx = random(2, 4);
    randomClr();
  }

  // Bounce off bottom edge
  if (y > height) {
    speedy = random(-4, -2);
    randomClr();
  }

  // Bounce off top edge
  if (y < th) {
    speedy = random(2, 4);
    randomClr();
  }
}
