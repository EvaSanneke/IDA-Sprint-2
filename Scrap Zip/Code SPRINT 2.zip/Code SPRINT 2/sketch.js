const s = (p) => {
  let speedx = 2;
  let speedy = 2;
  let x = 0;
  let y = 0;
  let clr = { r: 0, g: 0, b: 0 };
  // let tw, th;

  p.setup = () => {
    console.log("✅ instance mode setup");
    // Create the canvas and explicitly set width/height
    const canvas = p.createCanvas(p.windowWidth, p.windowHeight);

    // Directly set canvas styles using p5.js style method
    canvas.style("position", "fixed");
    canvas.style("top", "0");
    canvas.style("left", "0");
    canvas.style("width", "100vw");
    canvas.style("height", "100vh");
    canvas.style("z-index", "2147483647"); // Highest z-index
    canvas.style("pointer-events", "none"); // Allow clicks to pass through

    p.textSize(45);

    clr = {
      r: p.random(0, 255),
      g: p.random(0, 255),
      b: p.random(0, 255),
    };
    tw = p.textWidth("TAKE A BREAK");
    th = 22;
    x = p.random(0, p.width);
    y = p.random(th, p.height);
  };

  p.draw = () => {
    console.log("✅ draw is loaded");
    // p.clear(0);
    if (x > p.width - tw) {
      speedx = p.random(-4, -2);
      randomClr();
    }
    if (x < 0) {
      speedx = p.random(2, 4);
      randomClr();
    }
    if (y > p.height) {
      speedy = p.random(-4, -2);
      randomClr();
    }
    if (y < th) {
      speedy = p.random(2, 4);
      randomClr();
    }

    // p.noStroke();
    p.stroke(0);
    p.strokeWeight(1);
    p.fill(clr.r, clr.g, clr.b);
    p.text("TAKE A BREAK", x, y);

    x += speedx;
    y += speedy;
  };

  function randomClr() {
    clr.r = p.random(0, 255);
    clr.g = p.random(0, 255);
    clr.b = p.random(0, 255);
  }

  p.windowResized = () => {
    p.resizeCanvas(p.windowWidth, p.windowHeight);
  };
};

new p5(s);
