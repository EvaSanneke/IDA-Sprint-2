// Add the CSS
const link = document.createElement("link");
link.rel = "stylesheet";
link.href = browser.runtime.getURL("scrambler.css");
document.head.appendChild(link);

// Load p5.js first
const p5Script = document.createElement("script");
// p5Script.src = "https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.9.0/p5.min.js"; // or use
browser.runtime.getURL("p5.min.js");
p5Script.onload = () => {
  console.log("✅ p5.js loaded");

  // Now load the sketch
  const sketchScript = document.createElement("script");
  sketchScript.src = browser.runtime.getURL("sketch.js");
  sketchScript.onload = () => console.log("✅ sketch.js loaded");
  sketchScript.onerror = () => console.error("❌ Failed to load sketch.js");
  document.body.appendChild(sketchScript);
};

window.addEventListener("load", () => {
  document.documentElement.style.overflow = "visible";
  document.body.style.overflow = "visible";
});

p5Script.onerror = () => console.error("❌ Failed to load p5.js");
document.body.appendChild(p5Script);
